package b1;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class MyFIFO_App {
	public static <E> void stutter(Queue<E> input) {
		Queue<E> es = new LinkedList<E>();
		while (!input.isEmpty()) {
			es.add(input.remove());
		}
		while (!es.isEmpty()) {
			E e = es.remove();
			input.add(e);
			input.add(e);
		}
	}
	public static <E> void mirror(Queue<E> input) {
		Stack<E> stack = new Stack<>();
		for (E e : input) {
			stack.add(e);
		}
		while(!stack.isEmpty()) {
			input.add(stack.pop());
		}
	}

	public static void main(String[] args) {
		Queue<Integer> input = new LinkedList<Integer>();
		input.add(1);
		input.add(2);
		input.add(3);
		input.add(4);
		input.add(5);
//		stutter(input);
//		System.out.println(input);
		mirror(input);
		System.out.println(input);
	}
}
