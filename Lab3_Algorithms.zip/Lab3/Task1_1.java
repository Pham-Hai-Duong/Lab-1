package Lab3;

public class Task1_1 {
	public static int iterativeLinearSearch(int[] array, int target) {
		for (int i = 0; i < array.length; i++) {
			if (array[i] == target)
				return i;
		}
		return -1;
	}
	public static int recursiveLinearSearch(int[] array, int target) {
		return supportRecursive(array, target, 0);
	}

	public static int supportRecursive(int[] array, int target, int from) {
		if (from < array.length) {
			if (array[from] == target)
				return from;
			return supportRecursive(array, target, from + 1);
		}
		return -1;
	}
	
	public static void main(String[] args) {
		int[] array = { 12, 10, 9, 45, 2, 10, 10, 45 };
		System.out.println(iterativeLinearSearch(array, 45));
		System.out.println(recursiveLinearSearch(array, 15));
	}

}
