package Lab3;

public class Main {
	public static void main(String[] args) {
        // Create an order with two items.
        OrderItem[] items = new OrderItem[2];
        items[0] = new OrderItem(new Product("1", "Product 1", 10.0, "Electronics"), 1);
        items[1] = new OrderItem(new Product("2", "Product 2", 20.0, "Clothing"), 2);
        Order order = new Order(items);

        // Print the cost of the order.
        System.out.println("The cost of the order is " + order.cost());

        // Check if the order contains a product.
        System.out.println("The order contains product 1: " + order.contains(new Product("1", "Product 1", 10.0, "Electronics")));
        System.out.println("The order contains product 3: " + order.contains(new Product("3", "Product 3", 30.0, "Home")));

        // Filter the order by type.
        Product[] filteredProducts = order.filter("Clothing");
        for (Product product : filteredProducts) {
            System.out.println(product);
        }
    }

}
