package Lab3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Order {
	private OrderItem[] items;

	public Order(OrderItem[] items) {
		super();
		this.items = items;
	}

	public OrderItem[] getItems() {
		return items;
	}

	public void setItems(OrderItem[] items) {
		this.items = items;
	}
	public double cost() {
		  double totalCost = 0.0;

		  for (OrderItem item : items) {
		    totalCost += item.getQuality()* item.getP().getPrice();
		  }

		  return totalCost;
		}
	
	public boolean contains(Product p) {
		  // If the array is empty, return false.
		  if (items == null || items.length == 0) {
		    return false;
		  }

		  // Sort the array if it is not already sorted.
		  Arrays.sort(items, (i1, i2) -> i1.getP().getId().compareTo(i2.getP().getId()));

		  // Initialize the low and high indices.
		  int low = 0;
		  int high = items.length - 1;

		  // Perform binary search.
		  while (low <= high) {
		    int mid = (low + high) / 2;
		    int comparison = p.getId().compareTo(items[mid].getP().getId());

		    if (comparison == 0) {
		      // The product is found.
		      return true;
		    } else if (comparison < 0) {
		      // The product is in the left half of the array.
		      high = mid - 1;
		    } else {
		      // The product is in the right half of the array.
		      low = mid + 1;
		    }
		  }

		  // The product is not found.
		  return false;
		}
		
		public Product[] filter(String type) {
		  // If the array is empty, return an empty array.
		  if (items == null || items.length == 0) {
		    return new Product[0];
		  }

		  // Initialize a list to store the filtered products.
		  List<Product> filteredProducts = new ArrayList<>();

		  // Iterate over the array and add all products of the given type to the list.
		  for (OrderItem item : items) {
		    if (type.equals(item.getP().getType())) {
		      filteredProducts.add(item.getP());
		    }
		  }

		  // Convert the list to an array and return it.
		  return filteredProducts.toArray(new Product[filteredProducts.size()]);
		}


}
