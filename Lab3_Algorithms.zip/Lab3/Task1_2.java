package Lab3;

import java.util.Arrays;

public class Task1_2 {
	public static int iterativeBinarySearch(int[] array, int target) {
		int low = 0;
		int high = array.length - 1;
		while (low <= high) {
			int mid = (low + high) / 2;
			if (array[mid] == target)
				return mid;
			if (array[mid] > target)
				high = mid - 1;
			else
				low = mid + 1;
		}
		return -1;
	}

	public static int recursiveBinarySearch(int[] array, int target) {
		return supportRecursive(array, target, 0, array.length);
	}

	public static int supportRecursive(int[] array, int target, int low, int high) {
		int mid = (low + high) / 2;
		if (low <= high) {
			if (array[mid] == target)
				return mid;
			if (array[mid] > target)
				return supportRecursive(array, target, low, mid - 1);
			else
				return supportRecursive(array, target, mid + 1, high);
		}
		return -1;
	}
	
	public static void main(String[] args) {
		int[] array = { 12, 10, 9, 45, 2 };
		Arrays.sort(array);
		System.out.println(iterativeBinarySearch(array, 45));
		System.out.println(recursiveBinarySearch(array, 2));
	}

}
