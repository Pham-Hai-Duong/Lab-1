package Task1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyArray {
	private int[] array;
	public MyArray(int[] array) {
	this.array = array;
	}
	
	//Method mirror that outputs the contents of an array in a 
	//reverse order like a mirror 
	//Example: input [1, 2, 3] ==> output: [1, 2, 3, 3, 2, 1]
	public int[] mirror() {
		int[] result = new int[this.array.length*2];
		for(int i = 0; i < array.length;i++) {
			result[i] = array[i];
		}
		for(int i = 0; i < array.length;i++) {
			result[array.length*2-1-i] = array[i];
		}
	return result;
	}
	
	// removes all duplicate elements from an array and returns a 
	// new array
	//Input: 1 3 5 1 3 7 9 8
	//Output: 1 3 5 7 9 8
	public static int[] removeDuplicates(int[] arr) {
		int length = arr.length;
		int newLength = 0;
		boolean[] isDuplicated = new boolean[length];
		
		for(int i = 0; i < length;i++) {
			if(!isDuplicated[i]) {
				for(int j = i + 1;j < length; j++) {
					if(arr[i] == arr[j]) {
						isDuplicated[j] = true;
					}
				}
				newLength++;
			}
		}
		
		int[] result = new int[newLength];
		int index = 0;
		
		for(int i = 0;i < length; i++) {
			if(!isDuplicated[i]) {
				result[index++] = arr[i];
			}
		}
	return result;
	}
	private static void printArray(int[] arr) {
	    for (int i = 0; i < arr.length; i++) {
	        System.out.print(arr[i] + " ");
	    }
	    System.out.println();
	}
	
	// Input: 10 11 12 13 14 16 17 19 20 
	// Output: 15 18
	public int[] getMissingValues() {
		List<Integer> missingValues = new ArrayList<>();
		for (int i = 0; i < array.length; i++) {
		  if (i + 1 != array[i]) {
		    missingValues.add(i + 1);
		  }
		}
		int[] missingValuesArray = new int[missingValues.size()];
		  for (int i = 0; i < missingValuesArray.length; i++) {
		    missingValuesArray[i] = missingValues.get(i);
		}
	return missingValuesArray;
	}
	
	// Input: 10 11 12 -1 14 10 17 19 20
	// Output(k=3): 10 11 12 12 14 16 17 19 20
	public int[] fillMissingValues(int k) {
		int[] filledValuesArray = Arrays.copyOf(array, array.length);
	    for (int i = 0; i < filledValuesArray.length; i++) {
	      if (filledValuesArray[i] == -1) {
	          List<Integer> neighbors = new ArrayList<>();
	          for (int j = i - k; j <= i + k; j++) {
	              if (j >= 0 && j < filledValuesArray.length && filledValuesArray[j] != -1) {
	                  neighbors.add(filledValuesArray[j]);
	              }
	          }

	          int average = 0;
	          for (Integer neighbor : neighbors) {
	              average += neighbor;
	          }
	          average /= neighbors.size();

	          filledValuesArray[i] = average;
	      }
	  }
	  return filledValuesArray;
	}

	
	public static void main(String[] args) {
		int[] array = {1,2,3};
		MyArray ma = new MyArray(array);
		int[] re = ma.mirror();
		System.out.println(re);
		
		int[] arr = {1, 3, 5, 1, 3, 7, 9, 8};
		int[] result = removeDuplicates(arr);

		System.out.print("Input Array: " );
		    printArray(arr);

		System.out.print("Output Array: ");
		    printArray(result);
		
		MyArray ma1 = new MyArray(new int[]{10, 11, 12, 13, 14, 16, 17, 19, 20});
		int[] missingValues = ma1.getMissingValues();

		System.out.println("The missing values are:");
		for (int missingValue : missingValues) {
		  System.out.print(missingValue + " ");
		}
		System.out.println();
		
		MyArray myArray = new MyArray(new int[]{10, 11, 12, -1, 14, 10, 17, 19, 20});
		int[] filledValuesArray = myArray.fillMissingValues(3);

		System.out.println(Arrays.toString(filledValuesArray));
	}
	

}
