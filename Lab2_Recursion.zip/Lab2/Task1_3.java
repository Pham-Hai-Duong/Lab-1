package Lab2;

public class Task1_3 {
	 // This method is used to display a Pascal triangle based on the parameter n.
    // Where n represents the number of rows
    public static void printPascalTriangle(int row) {
        // Create a 2D array to store the Pascal triangle
        int[][] pascalTriangle = new int[row + 1][row + 1];

        // Initialize the first row of the Pascal triangle
        pascalTriangle[0][0] = 1;

        // Generate the remaining rows of the Pascal triangle
        for (int i = 1; i <= row; i++) {
            for (int j = 0; j <= i; j++) {
                // If we are at the beginning or end of the row, the value is 1
                if (j == 0 || j == i) {
                    pascalTriangle[i][j] = 1;
                } else {
                    // Otherwise, the value is the sum of the two values above it
                    pascalTriangle[i][j] = pascalTriangle[i - 1][j - 1] + pascalTriangle[i - 1][j];
                }
            }
        }

        // Print the Pascal triangle
        for (int i = 0; i <= row; i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print(pascalTriangle[i][j] + " ");
            }
            System.out.println();
        }
    }

    // get the nth row.
    //For example: n=1 ==> {1}, n=2 ==> {1, 1}, ...
    public static int[] getPascalTriangle(int n) {
        // Create an array to store the nth row of the Pascal triangle
        int[] pascalTriangleRow = new int[n + 1];

        // Initialize the first and last values of the row to 1
        pascalTriangleRow[0] = 1;
        pascalTriangleRow[n] = 1;

        // Generate the remaining values of the row
        for (int i = 1; i < n; i++) {
            pascalTriangleRow[i] = pascalTriangleRow[i - 1] + pascalTriangleRow[i];
        }

        return pascalTriangleRow;
    }

    // generate the next row based on the previous row
    //Ex. prevRow = {1} ==> nextRow = {1, 1}
    //Ex. prevRow = {1, 1} ==> nextRow = {1, 2, 1}
    public static int[] generateNextRow(int[] prevRow) {
        // Create an array to store the next row of the Pascal triangle
        int[] nextRow = new int[prevRow.length + 1];

        // Initialize the first and last values of the next row to 1
        nextRow[0] = 1;
        nextRow[nextRow.length - 1] = 1;

        // Generate the remaining values of the next row
        for (int i = 1; i < nextRow.length - 1; i++) {
            nextRow[i] = prevRow[i - 1] + prevRow[i];
        }

        return nextRow;
    }
    public static void main(String[] args) {
    	// Print the first 10 rows of the Pascal triangle
    	Task1_3.printPascalTriangle(4);

//    	// Get the 5th row of the Pascal triangle
//    	int[] pascalTriangleRow5 = Task1_3.getPascalTriangle(5);
//
//    	// Generate the next row of the Pascal triangle, based on the previous row
//    	int[] nextRow = Task1_3.generateNextRow(new int[]{1, 1});
	}

}
