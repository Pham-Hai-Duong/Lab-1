package QuanLySach;

public class AnPham {
	protected String title;
	protected int soTrang;
	protected int namxuatban;
	protected String tacgia;
	protected int gia;
	public AnPham(String title, int soTrang, int namxuatban, String tacgia, int gia) {
		super();
		this.title = title;
		this.soTrang = soTrang;
		this.namxuatban = namxuatban;
		this.tacgia = tacgia;
		this.gia = gia;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getSoTrang() {
		return soTrang;
	}
	public void setSoTrang(int soTrang) {
		this.soTrang = soTrang;
	}
	public int getNamxuatban() {
		return namxuatban;
	}
	public void setNamxuatban(int namxuatban) {
		this.namxuatban = namxuatban;
	}
	public String getTacgia() {
		return tacgia;
	}
	public void setTacgia(String tacgia) {
		this.tacgia = tacgia;
	}
	public int getGia() {
		return gia;
	}
	public void setGia(int gia) {
		this.gia = gia;
	}
	

}
