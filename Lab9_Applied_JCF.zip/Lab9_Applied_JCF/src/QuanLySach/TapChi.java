package QuanLySach;

public class TapChi extends AnPham{
	private String ten;
	
	public TapChi(String title, int soTrang, int namxuatban, String tacgia, int gia, String ten) {
		super(title, soTrang, namxuatban, tacgia, gia);
		this.ten = ten;
	}

	public String getTen() {
		return ten;
	}

	public void setTen(String ten) {
		this.ten = ten;
	}
	
}
