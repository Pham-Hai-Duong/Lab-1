package QuanLySach;

import java.util.List;

public class SachThamKhao extends AnPham{
	private String linhVuc;
	private List<ChuongSach> dsChuong;
	
	public SachThamKhao(String title, int soTrang, int namxuatban, String tacgia, int gia, String linhVuc,
			List<ChuongSach> dsChuong) {
		super(title, soTrang, namxuatban, tacgia, gia);
		this.linhVuc = linhVuc;
		this.dsChuong = dsChuong;
	}
	public String getLinhVuc() {
		return linhVuc;
	}
	public void setLinhVuc(String linhVuc) {
		this.linhVuc = linhVuc;
	}
	public List<ChuongSach> getDsChuong() {
		return dsChuong;
	}
	public void setDsChuong(List<ChuongSach> dsChuong) {
		this.dsChuong = dsChuong;
	}
	
}
