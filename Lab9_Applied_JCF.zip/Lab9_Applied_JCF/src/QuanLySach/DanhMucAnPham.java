package QuanLySach;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DanhMucAnPham {
	private List<AnPham> dmAnPham; 
	
//	6) Phương thức xác định loại của ấn phẩm (Tạp chí hay Sách tham khảo) 
	public String loaiAnPham(AnPham anPham) {
		if (anPham instanceof TapChi) {
			return "Tạp chí";
		} else {
			return "Sách tham khảo";
		}
	}

//	7) Phương thức kiểm tra ấn phẩm là tạp chí và có thời gian xuất bản cách đây 
//	(2021) 10 năm hay không
	public boolean isTapChiXin10NamTruoc(int namHienTai) {
		for(AnPham anPham : dmAnPham) {
		if (anPham instanceof TapChi && namHienTai - anPham.namxuatban >= 10) {
			return true;
		}}
		return false;
	}

//	8) Phương thức kiểm tra hai ấn phẩm có cùng loại và cùng tác giả hay không
	public boolean checkanPahm(AnPham anpham1, AnPham anpham2) {
		boolean f = false;
		if ((anpham1 instanceof TapChi) && (anpham2 instanceof TapChi)
				&& (anpham1.getTacgia().equals(anpham2.getTacgia()))) {
			f = true;
		} else if ((anpham1 instanceof SachThamKhao) && (anpham2 instanceof SachThamKhao)
				&& (anpham1.getTacgia().equals(anpham2.getTacgia()))) {
			f = true;
		}
		return f;
	}

//	9) Tính tổng tiền của tất các ấn phẩm trong nhà sách
	public int sum(AnPham anpham) {
		int sum = 0;
		for (AnPham anPham : dmAnPham) {
			sum = sum + anPham.getGia();
		}
		return sum;
	}
//	10)Tìm quyển sách tham khảo có chương sách nhiều trang nhất 
	public SachThamKhao timSachThamKhaoCoChuongNhieuTrangNhat(List<AnPham> dsAnPham) {
		SachThamKhao sachThamKhaoCoChuongNhieuTrangNhat = null;
		for (AnPham anPham : dsAnPham) {
			if (anPham instanceof SachThamKhao) {
				SachThamKhao sachThamKhao = (SachThamKhao) anPham;
				ChuongSach chuongNhieuTrangNhat = sachThamKhao.getDsChuong().stream()
						.max(Comparator.comparing(ChuongSach::getSoTrang)).get();
				if (sachThamKhaoCoChuongNhieuTrangNhat == null || chuongNhieuTrangNhat.getSoTrang() > sachThamKhaoCoChuongNhieuTrangNhat.getDsChuong().stream()
						.max(Comparator.comparing(ChuongSach::getSoTrang)).get().getSoTrang()) {
					sachThamKhaoCoChuongNhieuTrangNhat = sachThamKhao;
				}
			}
		}
		return sachThamKhaoCoChuongNhieuTrangNhat;
	}

//	11)Tìm xem trong danh sách các ấn phẩm có chứa một tạp chí có tên cho trước 
//	hay không?
	public boolean coTapChiCoTen(List<AnPham> dsAnPham, String tenTapChi) {
		for (AnPham anPham : dsAnPham) {
			if (anPham instanceof TapChi) {
				if (((TapChi) anPham).getTen().equals(tenTapChi)) {
					return true;
				}
			}
		}
		return false;
	}

//	12)Lấy ra danh sách các tạp chí được xuất bản vào 1 năm cho trước
	public List<TapChi> layDanhSachTapChiXuatBanNam(List<AnPham> dsAnPham, int nam) {
		List<TapChi> dsTapChi = new ArrayList<>();
		for (AnPham anPham : dsAnPham) {
			if (anPham instanceof TapChi) {
				if (((TapChi) anPham).getNamxuatban() == nam) {
					dsTapChi.add((TapChi) anPham);
				}
			}
		}
		return dsTapChi;
	}

//	13)Sắp xếp ấn phẩm tăng dần theo tiêu đề và giảm dần theo năm xuất bản (sử 
//	dụng interface Comparable hoặc Comparator)
	public void sapXepAnPhamTangDanTheoTieuDeGiamDanTheoNamXuatBan(List<AnPham> dsAnPham) {
		dsAnPham.sort(new Comparator<AnPham>() {
			@Override
			public int compare(AnPham o1, AnPham o2) {
				int soSanhTen = o1.getTitle().compareTo(o2.getTitle());
				if (soSanhTen != 0) {
					return soSanhTen;
				} else {
					return o2.getNamxuatban() - o1.getNamxuatban();
				}
			}
		});
	}

//	14)Thống kê số lượng ấn phẩm theo năm xuất bản. Ví dụ 2020: 5, 2021: 10, … 
//	năm 2020 có 5 ấn phẩm, năm 2021 có 10 ấn phẩm
	public Map<Integer, Integer> thongKeSoLuongAnPhamTheoNamXuatBan(List<AnPham> dsAnPham) {
		Map<Integer, Integer> mapSoLuongAnPham = new HashMap<>();
		for (AnPham anPham : dsAnPham) {
			int namXuatBan = anPham.getNamxuatban();
			if (mapSoLuongAnPham.containsKey(namXuatBan)) {
				mapSoLuongAnPham.put(namXuatBan, mapSoLuongAnPham.get(namXuatBan) + 1);
			} else {
				mapSoLuongAnPham.put(namXuatBan, 1);
			}
		}
		return mapSoLuongAnPham;
	}

}
