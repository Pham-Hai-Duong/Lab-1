package QuanLySach;

public class ChuongSach {
	private String tieuDe;
	private int soTrang;
	public ChuongSach(String tieuDe, int soTrang) {
		super();
		this.tieuDe = tieuDe;
		this.soTrang = soTrang;
	}
	public String getTieuDe() {
		return tieuDe;
	}
	public void setTieuDe(String tieuDe) {
		this.tieuDe = tieuDe;
	}
	public int getSoTrang() {
		return soTrang;
	}
	public void setSoTrang(int soTrang) {
		this.soTrang = soTrang;
	}
	
}
