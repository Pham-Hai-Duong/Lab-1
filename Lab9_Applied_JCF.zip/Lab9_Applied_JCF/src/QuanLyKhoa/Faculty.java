package CTDL;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Faculty {
	private String name;
	private String address;
	private List<Course> courses;
	public Faculty(String name, String address, List<Course> coursers) {
		super();
		this.name = name;
		this.address = address;
		this.courses = coursers;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public List<Course> getCoursers() {
		return courses;
	}
	public void setCoursers(List<Course> coursers) {
		this.courses = coursers;
	}
	 public Course getMaxPracticalCourse() {
		Course re = null;
		for(Course c: courses) {
			if(c.getType().equals("TH")) {
				if(re == null) {
					re=c;
				}else if(c.getStudents().size()>re.getStudents().size()) {
					re=c;
				}
			}
		}
		return re;
	 }
	 public Map<Integer, List<Student>> groupStudentsByYear() {
		    Map<Integer, List<Student>> re = new HashMap<>();
		    for (Course c : courses) {
		        for (Student st : c.getStudents()) {
		            int key = st.getYear();
		            List<Student> value = new ArrayList<>();
		            if (re.containsKey(key)) {
		                value = re.get(key);
		                if (!value.contains(st)) {
		                    value.add(st);
		                }
		            } else {
		                value = new ArrayList<>();
		                value.add(st);
		                re.put(key, value);
		            }
		        }
		    }
		    return re;
		}
	 public Set<Course> filterCourses(String type) {
		    Set<Course> re = new TreeSet<>((Course c1, Course c2) -> {
		        if (c1.getStudents().size() > c2.getStudents().size()) {
		            return -1;
		        } else if (c1.getStudents().size() < c2.getStudents().size()) {
		            return 1;
		        } else {
		            return c1.getTitle().compareTo(c2.getTitle());
		        }
		    });
		    for (Course c : courses) {
		        if (c.getType().equals(type)) {
		            re.add(c);
		        }
		    }
		    return re;
		}


}
