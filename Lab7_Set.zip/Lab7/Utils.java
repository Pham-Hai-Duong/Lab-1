package Lab7;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

public class Utils {
	public static List<String> loadUtils(String fileName) throws FileNotFoundException {
		List<String> res = new ArrayList<>();
		Scanner input = new Scanner(new File(fileName));
		while (input.hasNext()) {
			String words = input.next();
			res.add(words);
		}
		return res;

	}

	 public static List<String> loadWord(String fileName) throws FileNotFoundException {
	        List<String> words = new ArrayList<>();
	        try (Scanner scanner = new Scanner(new File(fileName))) {
	            while (scanner.hasNextLine()) {
	                String line = scanner.nextLine();
	                for (String word : line.split("\\W+")) {
	                    words.add(word);
	                }
	            }
	        }
	        return words;
	    }
	
	
}