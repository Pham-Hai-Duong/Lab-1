package Lab10_Tree;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class BST<E extends Comparable<E>> {
	private BNode<E> root;

	public BST() {
		this.root = null;
	}

	// Add element e into BST
	public void add(E e) {
		root = add(e, root);
	}

	private BNode<E> add(E e, BNode<E> node) {
		if (node == null) {
			node = new BNode<E>(e);
		} else if (node.compareTo(e) > 0) {
			node.setLeft(add(e, node.getLeft()));
		} else if (node.compareTo(e) < 0) {
			node.setRight(add(e, node.getRight()));
		}
		return node;
	}

	// Add a collection of elements col into BST
	public void add(Collection<E> col) {
		for (E element : col) {
			add(element);
		}
	}

	// compute the depth of a node in BST
	public int depth(E node) {
		if (root == null) {
			return -1;
		} else if (!contains(node)) {
			return -1;
		}
		return root.depth(node);
	}

	// compute the height of BST
	public int height() {
		if (root == null) {
			return -1;
		}
		return root.height();
	}

	// Compute total nodes in BST
	public int size() {
		return countNodes(root);
	}

	private int countNodes(BNode<E> node) {
		if (node == null) {
			return 0;
		}
		int leftCount = countNodes(node.getLeft());
		int rightCount = countNodes(node.getRight());
		return leftCount + rightCount + 1;
	}

	// Check whether element e is in BST
	public boolean contains(E e) {
		if (root == null)
			return false;
		return root.constain(e);
	}

	// Find the minimum element in BST
	public E findMin() {
		if (root == null)
			return null;
		return root.findMin();
	}

	// Find the maximum element in BST
	public E findMax() {
		if (root == null)
			return null;
		return root.findMax();
	}

	// Remove element e from BST
	public boolean remove(E e) {
		if (root == null)
			return false;
		else if (!contains(e))
			return false;
		else {
			root = root.remove(root, e);
			return true;
		}
	}

	// get the descendants of a node
	public List<E> descendants(E data) {
		return root.descendants(data, root);
	}

	// get the ancestors of a node
	public List<E> ancestors(E data) {
		return root.ancestors(data, root);
	}

	// display BST using inorder approach
	public void inorder() {
		inorder(root);
    }

    private void inorder(BNode<E> node) {
        if (node != null) {
            inorder(node.getLeft());
            System.out.print(node.getData() + " ");
            inorder(node.getRight());
        }
    }

	// display BST using preorder approach
	public void preorder() {
		preorder(root);
    }

    private void preorder(BNode<E> node) {
        if (node != null) {
            System.out.print(node.getData() + " ");
            preorder(node.getLeft());
            preorder(node.getRight());
        }
    }

	// display BST using postorder approach
	public void postorder() {
		postorder(root);
    }

    private void postorder(BNode<E> node) {
        if (node != null) {
            postorder(node.getLeft());
            postorder(node.getRight());
            System.out.print(node.getData() + " ");
        }
    }
	
	public static void main(String[] args) {
		BST<Integer> bst = new BST<>();
		bst.add(25);
		bst.add(15);
		bst.add(50);
		bst.add(10);
		bst.add(22);
		bst.add(4);
		bst.add(12);
		bst.add(18);
		bst.add(24);
		bst.add(35);
		bst.add(31);
		bst.add(44);
		bst.add(70);
		bst.add(66);
		bst.add(90);


//		System.out.println(bst);
//		System.out.println(bst.size());
//		System.out.println(bst.depth(15));
//		System.out.println(bst.constain(15));
//		System.out.println(bst.height());
//		System.out.println(bst.findMin());
//		System.out.println(bst.findMax());
//		System.out.println(bst);
//		System.out.println(bst.remove(2));
//		System.out.println(bst);
//		System.out.println(bst.descendants(30));
		System.out.println(bst.ancestors(10)); 

		System.out.println("Inorder:");
		bst.inorder();

		System.out.println("\nPreorder:");
		bst.preorder();

		System.out.println("\nPostorder:");
		bst.postorder();
	}

}