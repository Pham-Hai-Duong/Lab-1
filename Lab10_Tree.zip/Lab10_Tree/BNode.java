package Lab10_Tree;

import java.util.ArrayList;
import java.util.List;

public class BNode<E extends Comparable<E>> {
	private E data;
	private BNode<E> left;
	private BNode<E> right;

	public BNode(E data) {
		this.data = data;
		this.left = null;
		this.right = null;
	}

	public BNode(E data, BNode<E> left, BNode<E> right) {
		this.data = data;
		this.left = left;
		this.right = right;
	}

	public E getData() {
		return data;
	}

	public void setData(E data) {
		this.data = data;
	}

	public BNode<E> getLeft() {
		return left;
	}

	public void setLeft(BNode<E> left) {
		this.left = left;
	}

	public BNode<E> getRight() {
		return right;
	}

	public void setRight(BNode<E> right) {
		this.right = right;
	}

	public int compareTo(E e) {
		return data.compareTo(e);
	}

	public int depth(E e) {
		if (this.data.compareTo(e) == 0) {
			return 0;
		} else if (this.data.compareTo(e) > 0) {
			return 1 + left.depth(e);
		} else {
			return 1 + right.depth(e);
		}
	}

	public int height() {
		if (left == null && right == null) {
			return 0;
		} else if (left != null && right == null) {
			return 1 + left.height();
		} else if (left == null && right != null) {
			return 1 + right.height();
		}
		return 1 + Math.max(left.height(), right.height());
	}

	public boolean constain(E e) {
		if (this.data.compareTo(e) == 0)
			return true;
		if (left == null && right == null)
			return false;
		if (this.data.compareTo(e) > 0 && left == null)
			return false;
		if (this.data.compareTo(e) < 0 && right == null)
			return false;
		if (this.data.compareTo(e) > 0)
			return left.constain(e);
		return right.constain(e);
	}

	public List<E> descendants(E e, BNode<E> node) {
		List<E> list = new ArrayList<E>();
		if (node == null)
			return list;
		else if (node.data == e)
			return list;
		else {
			list.add(node.data);
			if (e.compareTo(node.data) > 0)
				list.addAll(descendants(e, node.right));
			if (e.compareTo(node.data) < 0)
				list.addAll(descendants(e, node.left));
		}
		return list;
	}

	public E findMin() {
		if (left == null)
			return this.data;
		if (this.data.compareTo(left.data) < 0)
			return this.data;
		return left.findMin();
	}

	public E findMax() {
		if (right == null)
			return this.data;
		if (this.data.compareTo(right.data) > 0)
			return this.data;
		return right.findMax();
	}

	public BNode<E> remove(BNode<E> node, E e) {
		if (node.data.compareTo(e) > 0)
			node.left = remove(node.left, e);
		else if (node.data.compareTo(e) < 0)
			node.right = remove(node.right, e);
		else {
			if (node.left == null && node.right == null)
				return null;
			else if (node.left == null)
				return node.right;
			else if (node.right == null)
				return node.left;
			else {
				node.data = node.left.findMax();
				node.left = remove(node.left, node.data);
			}
		}
		return node;
	}

	public List<E> ancestors(E e, BNode<E> node) {
		List<E> list = new ArrayList<E>();
		if (node == null)
			return list;
		if (e.compareTo(node.data) > 0)
			list = ancestors(e, node.right);
		else if (e.compareTo(node.data) < 0)
			list = ancestors(e, node.left);
		else {
			if (node.left == null && node.right == null)
				return list;
			else if (node.left == null) {
				list.add(node.right.data);
				list.addAll(ancestors(node.right.data, node.right));
			}else if (node.right == null) {
				list.add(node.left.data);
				list.addAll(ancestors(node.left.data, node.left));
			}else {
				list.add(node.left.data);
				list.add(node.right.data);
				list.addAll(ancestors(node.right.data, node.right));
				list.addAll(ancestors(node.left.data, node.left));
			}
		}
		return list;
	}

}
